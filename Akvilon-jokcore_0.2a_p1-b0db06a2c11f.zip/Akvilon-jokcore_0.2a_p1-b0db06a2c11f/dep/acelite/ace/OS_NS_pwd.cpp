// $Id: OS_NS_pwd.cpp 91781 2010-09-15 12:49:15Z johnnyw $

#include "ace/OS_NS_pwd.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_pwd.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

