// -*- C++ -*-
// $Id: OS_NS_ctype.cpp 91683 2010-09-09 09:07:49Z johnnyw $

#include "ace/OS_NS_ctype.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_ctype.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

