// $Id: OS_NS_poll.cpp 91626 2010-09-07 10:59:20Z johnnyw $

#include "ace/OS_NS_poll.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_poll.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

