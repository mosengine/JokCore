// $Id: OS_NS_sys_select.cpp 91626 2010-09-07 10:59:20Z johnnyw $

#include "ace/OS_NS_sys_select.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_sys_select.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

